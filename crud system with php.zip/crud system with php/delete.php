<?php
include 'config.php';

$id = $_GET['id'];

$q= " DELETE FROM `abhi` WHERE id = $id";

mysqli_query($conn, $q);
header('location: display.php');
?>