

<html>
<head>
	<title>
		CRUD SYSTEM
	</title>

<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js">
	
</script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js">
	
</script>
</head>
<body>

 <div class="container">
 <div class="col-lg-12">
 	<br>
 	<br>
 	<h1 class="text-warning text-center"> Display table data</h1><br>
 	<br>
 	<table class="table-striped table-hover table-bordered">
 		<tr clASS="bg-dark text-white text-center">
 			<th>Id </th>
 			<th>Username</th>
 			<th>Passowrd</th>
 			<th>Delete</th>
 			<th>update</th>
 		</tr >
<?php
		include 'config.php';

		$q=" SELECT * FROM abhi";
		$query=mysqli_query($conn,$q);
  while($res=mysqli_fetch_array($query))
  {

?>
 		<tr class="text-center">
   <td><?php echo $res['id']; ?>
   	
   </td>
    <td><?php echo $res['username']; ?></td>
    <td><?php echo $res['password']; ?></td>
    <td>   <button class="btn-danger btn"> <a href="delete.php?id=<?php echo $res['id'];?>" class="text-white"> Delete</a> </button> </td>

 <td>   <button class="btn-primary btn"> <a href="update.php?id=<?php echo $res['id'];?>" class="text-white">Update </a> </button> </td>





    
 			

 		</tr>
 		<?php 
 		}
 		?>
 	</table>
</div>
</div>

</body>
</html>
