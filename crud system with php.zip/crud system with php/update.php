<?php

include 'config.php';
$id=$_GET['id'];
if(isset($_POST['done']))
{
	$username=$_POST['username'];
	$password=$_POST['password'];

 $q="UPDATE abhi SET username='$username', password='$password' WHERE id=$id";
$query=mysqli_query($conn,$q);
header('location:display.php');


}



$sql1="SELECT * FROM `abhi` where `id`='$id'";
$result1=mysqli_query($conn,$sql1);
$row=mysqli_fetch_array($result1);



?>
  <html>
<head>
	<title>
		CRUD SYSTEM
	</title>

<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>


	</head>

	<body>
<div class="col-lg-6 m-auto">
<form method="POST">
	<br>
	<br>
	<div class="card">
		<div class="card-header bg-dark">
			<h1 class="text-white text-center">UPDATE Operation</h1>

		</div> 
		<label>USERNAME:
		</label>
		<input type="text" name="username" class="form-control" value="<?php echo $row['username']; ?>"><br>

			<label>Password:
		</label>
		<input type="text" name="password" class="form-control" value="<?php echo $row['password']; ?>">
			<br>


			<button class="btn btn-success"  type="submit" name="done">Submit</button>
			<br>


	</div>
</form>

	</body>
	</html>
